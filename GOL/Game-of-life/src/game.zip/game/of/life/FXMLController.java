package game.of.life;

import java.io.IOException;
import java.net.URL;
import java.util.Arrays;
import java.util.ResourceBundle;
import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.MenuBar;
import javafx.scene.paint.Color;
import javafx.scene.input.MouseEvent;
import javafx.util.Duration;

public class FXMLController implements Initializable 
{
    @FXML
    private Canvas canvas;
    @FXML
    private ColorPicker colorPicker;
    @FXML
    private MenuBar menubar;
    GraphicsContext graphicsContext;

    Logikk brettNextGen;
    Tegner draw;
    double canvasWidth;
    double canvasHeight;
    int antallruterx = 20;
    int antallrutery = 20;
    int[][] array = new int[antallruterx][antallrutery];
    long frekvens = 80;

    @FXML
    private void setFill() 
    {
        
    }

    @FXML
    public void nullstillGameboard(ActionEvent event)
    {
      

    }

    public void startSpill() {
        

    final Timeline timeline = new Timeline();
    timeline.setCycleCount(-1);
    timeline.setAutoReverse(true);
    
    timeline.getKeyFrames().add(new KeyFrame(Duration.millis(frekvens),
    (ActionEvent event) ->{
     brettNextGen.nextGen();
            draw.tegnGrid(brettNextGen.getArray());      
    }));
    timeline.play();

    }

    @Override
    public void initialize(URL location, ResourceBundle resources)
    {
        graphicsContext = canvas.getGraphicsContext2D();
        canvasWidth = canvas.getWidth();
        canvasHeight = canvas.getHeight();
        graphicsContext.setLineWidth(3);

        graphicsContext.setFill(Color.WHITE);
        graphicsContext.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        graphicsContext.strokeRect(0, 0, canvas.getWidth(), canvas.getHeight());
        
        //Fargen på celle ved start
        colorPicker.setValue(Color.TEAL);
       
        //GRID
        graphicsContext.setStroke(Color.GREY);
        
        brettNextGen = new Logikk(array, canvasWidth, canvasHeight);
        draw = new Tegner(canvasWidth, canvasHeight, graphicsContext, antallruterx, antallrutery, colorPicker);
        draw.tegnGrid(brettNextGen.getArray());

        
        colorPicker.setOnAction((ActionEvent event) -> 
        {
            //draw.setFill(colorPicker.getValue());
        });

        colorPicker.setValue(colorPicker.getValue()); //Endre farge på colorpicker penne

        graphicsContext.setStroke(colorPicker.getValue()); // Velger farge

        canvas.addEventHandler(MouseEvent.MOUSE_CLICKED, (MouseEvent event)
                -> {
            draw.finnrect(brettNextGen.getArray(), (int) event.getX(), (int) event.getY());
        });

        canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, (MouseEvent event)
                -> {
            draw.finnrect(brettNextGen.getArray(), (int) event.getX(), (int) event.getY());
        }
        );

        canvas.addEventHandler(MouseEvent.MOUSE_RELEASED, (MouseEvent event)
                -> {
            //Når musen slippes
        }
        );

    }
}
